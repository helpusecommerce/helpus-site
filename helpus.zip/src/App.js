// App.js com rotas por categoria de serviços
import React, { useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Header from './components/Header';
import Hero from './components/Hero';
import Footer from './components/Footer';
import Servicos from './pages/Servicos';
import Sobre from './pages/Sobre';
import Contato from './pages/Contato';
import Vistos from './pages/Vistos';
import Empresa from './pages/Empresa';
import Fiscal from './pages/Fiscal';
import AOS from 'aos';
import 'aos/dist/aos.css';

function App() {
  useEffect(() => {
    AOS.init({ duration: 1000, once: true });
  }, []);

  return (
    <Router>
      <div className="pt-20 flex flex-col min-h-screen scroll-smooth">
        <Header />
        <main className="flex-grow">
          <Routes>
            <Route path="/" element={<Hero />} />
            <Route path="/servicos" element={<Servicos />} />
            <Route path="/servicos/vistos" element={<Vistos />} />
            <Route path="/servicos/empresa" element={<Empresa />} />
            <Route path="/servicos/fiscal" element={<Fiscal />} />
            <Route path="/sobre" element={<Sobre />} />
            <Route path="/contato" element={<Contato />} />
          </Routes>
        </main>
        <Footer />
      </div>
    </Router>
  );
}

export default App;
